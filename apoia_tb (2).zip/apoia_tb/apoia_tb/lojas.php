<?php

include "header.php";
include "conexaoBD.php";

$sql = "SELECT 
            id_usuario,
            nome_empresa,
            cidade_usuario,
            instagram_usuario,
            site_usuario
        FROM usuario
        WHERE tipo_usuario = 'Microempreendedor'
        AND status_usuario = 'Ativo'
        ORDER BY nome_empresa ASC";

$resultado = mysqli_query($conn, $sql);

?>

<div class="container mt-5 mb-5">

    <h1 class="text-center mb-5">
        🏪 Nossas Lojas
    </h1>

    <div class="row">

        <?php while ($loja = mysqli_fetch_assoc($resultado)) { ?>

            <div class="col-md-4 mb-4">

                <div class="card h-100 shadow-sm">

                    <div class="card-body">

                        <h4 class="card-title fw-bold">
                            <?= htmlspecialchars($loja['nome_empresa']) ?>
                        </h4>

                        <?php if (!empty($loja['cidade_usuario'])) { ?>

                            <p class="text-muted">
                                📍 <?= htmlspecialchars($loja['cidade_usuario']) ?>
                            </p>

                        <?php } ?>

                        <?php if (!empty($loja['instagram_usuario'])) { ?>

                            <p>
                                📸 <?= htmlspecialchars($loja['instagram_usuario']) ?>
                            </p>

                        <?php } ?>

                        <?php if (!empty($loja['site_usuario'])) { ?>

                            <a 
                                href="<?= htmlspecialchars($loja['site_usuario']) ?>"
                                target="_blank"
                                class="btn btn-primary me-2 mb-2"
                            >
                                🌐 Visitar site
                            </a>

                        <?php } ?>

                        <a 
                            href="loja.php?id=<?= $loja['id_usuario'] ?>"
                            class="btn btn-dark mb-2"
                        >
                            🏪 Ver loja
                        </a>

                    </div>

                </div>

            </div>

        <?php } ?>

    </div>

</div>

<?php include "footer.php"; ?>