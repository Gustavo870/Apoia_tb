<?php

    include "conexaoBD.php"; //Inclui o arquivo de conexão com o BD para consultar usuários
    session_start(); //Função para iniciar uma sessão

    $emailUsuario = mysqli_real_escape_string($conn, $_POST['email_usuario']);
    $senhaUsuario = mysqli_real_escape_string($conn, $_POST['senha_usuario']);

    //QUERY para buscar dados de Login
    $buscarLogin = "SELECT *
                    FROM usuario
                    WHERE email_usuario = '$emailUsuario'
                    AND senha_usuario = md5('$senhaUsuario')";

    $efetuarLogin = mysqli_query($conn, $buscarLogin); //Executa a QUERY

    //Verifica se encontrou registros associados à a consulta
    if($registro = mysqli_fetch_assoc($efetuarLogin)){
        //Cria variáveis de sessão
        $_SESSION['id_usuario']    = $registro['id_usuario'];
        $_SESSION['nome_usuario']  = $registro['nome_usuario'];
        $_SESSION['email_usuario'] = $registro['email_usuario'];
        $_SESSION['cpf_cnpj_usuario'] = $registro['cpf_cnpj_usuario'];  
        $_SESSION['logado']       = true;

        //Redirecion o usuário para a página inicial
        header("Location: index.php");
        exit();
    }
    else{
        //Redireciona o usuário para formLogin.php
        header("Location: formLogin.php?erroLogin=dadosInvalidos"); //Passa por GET o erro ocorrido
        exit();
    }


?>