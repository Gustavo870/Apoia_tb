<?php session_start();?>

<?php include "header.php"?>

<?php
include "conexaobd.php";

$sql = "SELECT * FROM Anuncios";
$resultado = mysqli_query($conn, $sql);
?>

<div class="container">

    <div class="row">

        <!-- Área dos Posts -->
        <div class="col-lg-8">

            <div class="row">

                <?php
                while($post = mysqli_fetch_assoc($resultado)) {
                ?>

                    <div class="col-lg-6 mb-4">

                        <div class="card h-100">

                            <img src="<?= $post['fotoAnuncio'] ?>" 
                                class="card-img-top"
                                alt="<?= $post['tituloAnuncio'] ?>">

                            <div class="card-body d-flex flex-column">

                                <h2 class="card-title">
                                    <?= $post['tituloAnuncio'] ?>
                                </h2>

                                <p class="card-text">
                                    <?= $post['descricaoAnuncio'] ?>
                                </p>
                                
                                <p class="card-text">
                                    <?= $post['valorAnuncio'] ?>
                                </p>

                                <a href="post.php?id=<?= $post['IdAnuncio'] ?>" 
                                   class="btn btn-primary mt-auto">
                                    Ler mais
                                </a>

                            </div>

                        </div>

                    </div>

                <?php
                }
                ?>

            </div>

        </div>

        <!-- Sidebar -->
        <?php include "widgtes.php"; ?>

    </div>

</div>

<!-- Pagination-->
<nav aria-label="Pagination">
    <hr class="my-0" />

    <ul class="pagination justify-content-center my-4">

        <li class="page-item disabled">
            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">
                Retornar
            </a>
        </li>

        <li class="page-item active" aria-current="page">
            <a class="page-link" href="#!">1</a>
        </li>

        <li class="page-item">
            <a class="page-link" href="#!">2</a>
        </li>

        <li class="page-item">
            <a class="page-link" href="#!">3</a>
        </li>

        <li class="page-item disabled">
            <a class="page-link" href="#!">...</a>
        </li>

        <li class="page-item">
            <a class="page-link" href="#!">15</a>
        </li>

        <li class="page-item">
            <a class="page-link" href="#!">Avançar</a>
        </li>

    </ul>
</nav>

<?php include "footer.php"?>