<?php

session_start();

include "conexaoBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION['id_usuario'];


// ==========================================
// RECEBER DADOS DO FORMULÁRIO
// ==========================================

$nome_usuario = trim($_POST['nome_usuario'] ?? '');
$email_usuario = trim($_POST['email_usuario'] ?? '');
$cidade_usuario = trim($_POST['cidade_usuario'] ?? '');
$telefone_usuario = trim($_POST['telefone_usuario'] ?? '');
$endereco_usuario = trim($_POST['endereco_usuario'] ?? '');
$instagram_usuario = trim($_POST['instagram_usuario'] ?? '');


// ==========================================
// VERIFICAR CAMPOS OBRIGATÓRIOS
// ==========================================

if (
    empty($nome_usuario) ||
    empty($email_usuario) ||
    empty($cidade_usuario)
) {

    header("Location: perfil.php?erro=1");
    exit();
}


// ==========================================
// PROTEGER OS DADOS
// ==========================================

$nome_usuario = mysqli_real_escape_string($conn, $nome_usuario);
$email_usuario = mysqli_real_escape_string($conn, $email_usuario);
$cidade_usuario = mysqli_real_escape_string($conn, $cidade_usuario);
$telefone_usuario = mysqli_real_escape_string($conn, $telefone_usuario);
$endereco_usuario = mysqli_real_escape_string($conn, $endereco_usuario);
$instagram_usuario = mysqli_real_escape_string($conn, $instagram_usuario);


// ==========================================
// VERIFICAR SE FOI ENVIADA UMA FOTO
// ==========================================

$fotoLoja = null;

if (
    isset($_FILES['foto_loja']) &&
    $_FILES['foto_loja']['error'] === UPLOAD_ERR_OK
) {

    $nomeOriginal = $_FILES['foto_loja']['name'];
    $arquivoTemporario = $_FILES['foto_loja']['tmp_name'];
    $tamanhoArquivo = $_FILES['foto_loja']['size'];

    // Pegar extensão
    $extensao = strtolower(
        pathinfo($nomeOriginal, PATHINFO_EXTENSION)
    );


    // Extensões permitidas
    $extensoesPermitidas = [
        'jpg',
        'jpeg',
        'png',
        'webp'
    ];


    // Verificar extensão
    if (!in_array($extensao, $extensoesPermitidas)) {

        header("Location: perfil.php?erro=foto");
        exit();

    }


    // Limite de 5 MB
    if ($tamanhoArquivo > 5 * 1024 * 1024) {

        header("Location: perfil.php?erro=tamanho");
        exit();

    }


    // ==========================================
    // CRIAR PASTA DAS FOTOS
    // ==========================================

    $pasta = "assets/img/lojas/";


    if (!is_dir($pasta)) {

        mkdir($pasta, 0777, true);

    }


    // ==========================================
    // CRIAR NOME ÚNICO
    // ==========================================

    $nomeArquivo = "loja_" . $idUsuario . "_" . time() . "." . $extensao;

    $caminhoFoto = $pasta . $nomeArquivo;


    // ==========================================
    // SALVAR A FOTO
    // ==========================================

    if (move_uploaded_file(
        $arquivoTemporario,
        $caminhoFoto
    )) {

        $fotoLoja = mysqli_real_escape_string(
            $conn,
            $caminhoFoto
        );

    } else {

        header("Location: perfil.php?erro=upload");
        exit();

    }

}


// ==========================================
// ATUALIZAR DADOS
// ==========================================

if ($fotoLoja !== null) {

    // Atualiza os dados + foto

    $sql = "UPDATE usuario SET

                nome_usuario = '$nome_usuario',
                email_usuario = '$email_usuario',
                cidade_usuario = '$cidade_usuario',
                telefone_usuario = '$telefone_usuario',
                endereco_usuario = '$endereco_usuario',
                instagram_usuario = '$instagram_usuario',
                fotoLoja = '$fotoLoja'

            WHERE id_usuario = $idUsuario";


} else {

    // Atualiza somente os dados
    // Mantém a foto antiga

    $sql = "UPDATE usuario SET

                nome_usuario = '$nome_usuario',
                email_usuario = '$email_usuario',
                cidade_usuario = '$cidade_usuario',
                telefone_usuario = '$telefone_usuario',
                endereco_usuario = '$endereco_usuario',
                instagram_usuario = '$instagram_usuario'

            WHERE id_usuario = $idUsuario";

}


// ==========================================
// EXECUTAR UPDATE
// ==========================================

if (mysqli_query($conn, $sql)) {

    $_SESSION['nome_usuario'] = $nome_usuario;

    header("Location: perfil.php?sucesso=1");
    exit();

} else {

    echo "Erro ao atualizar perfil: " . mysqli_error($conn);

}

?>