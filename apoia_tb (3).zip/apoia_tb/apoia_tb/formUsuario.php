<?php include "header.php" ?>


<div class="d-flex justify-content-center mb-3">

    <h2>Cadastre-se</h2>

</div>


<div class="d-flex justify-content-center mb-4">

    <form
        action="actionUsuario.php"
        method="POST"
        class="was-validated w-25"
    >


        <!-- ========================= -->
        <!-- NOME -->
        <!-- ========================= -->

        <div class="form-floating mt-3 mb-3">

            <input
                type="text"
                name="nome_usuario"
                id="nome_usuario"
                placeholder="Nome Completo"
                class="form-control"
                required
            >

            <label for="nome_usuario">
                Nome
            </label>

        </div>


        <!-- ========================= -->
        <!-- CPF / CNPJ -->
        <!-- ========================= -->

        <div class="form-floating mt-3 mb-3">

            <input
                type="text"
                name="cpf_cnpj_usuario"
                id="cpf_cnpj_usuario"
                class="form-control"
                placeholder="CPF ou CNPJ"
                maxlength="18"
                required
            >

            <label for="cpf_cnpj_usuario">
                CPF ou CNPJ
            </label>

        </div>


        <!-- ========================= -->
        <!-- AVISO CNPJ -->
        <!-- ========================= -->

        <div
            id="avisoCnpj"
            class="alert alert-info text-center"
            style="display: none;"
        >

            <strong>CNPJ identificado!</strong>

            <br>

            Preencha os dados da sua empresa.

        </div>


        <!-- ========================= -->
        <!-- DADOS DA EMPRESA -->
        <!-- ========================= -->

        <div
            id="dadosEmpresa"
            style="display: none;"
        >


            <!-- NOME DA EMPRESA -->

            <div class="form-floating mt-3 mb-3">

                <input
                    type="text"
                    name="nome_empresa"
                    id="nome_empresa"
                    placeholder="Nome da empresa"
                    class="form-control"
                >

                <label for="nome_empresa">
                    Nome da empresa
                </label>

            </div>


            <!-- TELEFONE -->

            <div class="form-floating mt-3 mb-3">

                <input
                    type="text"
                    name="telefone_usuario"
                    id="telefone_usuario"
                    placeholder="Telefone"
                    class="form-control"
                >

                <label for="telefone_usuario">
                    Telefone / WhatsApp
                </label>

            </div>


            <!-- ENDEREÇO -->

            <div class="form-floating mt-3 mb-3">

                <input
                    type="text"
                    name="endereco_usuario"
                    id="endereco_usuario"
                    placeholder="Endereço"
                    class="form-control"
                >

                <label for="endereco_usuario">
                    Endereço
                </label>

            </div>


            <!-- INSTAGRAM -->

            <div class="form-floating mt-3 mb-3">

                <input
                    type="text"
                    name="instagram_usuario"
                    id="instagram_usuario"
                    placeholder="@instagram"
                    class="form-control"
                >

                <label for="instagram_usuario">
                    Instagram
                </label>

            </div>


        </div>


        <!-- ========================= -->
        <!-- DATA DE NASCIMENTO -->
        <!-- ========================= -->

        <div
            class="form-floating mt-3 mb-3"
            id="divDataNascimento"
        >

            <input
                type="date"
                name="dataNascimento_Usuario"
                id="dataNascimento_Usuario"
                class="form-control"
            >

            <label for="dataNascimento_Usuario">
                Data de Nascimento
            </label>

        </div>


        <!-- ========================= -->
        <!-- CIDADE -->
        <!-- ========================= -->

        <div class="form-floating mt-3 mb-3">

            <select
                name="cidade_usuario"
                id="cidade_usuario"
                class="form-control"
                required
            >

                <option value="Curiúva">
                    Curiúva
                </option>

                <option value="Imbaú">
                    Imbaú
                </option>

                <option value="Ortigueira">
                    Ortigueira
                </option>

                <option value="Reserva">
                    Reserva
                </option>

                <option
                    value="Telêmaco Borba"
                    selected
                >
                    Telêmaco Borba
                </option>

                <option value="Tibagi">
                    Tibagi
                </option>

            </select>

            <label for="cidade_usuario">
                Cidade
            </label>

        </div>


        <!-- ========================= -->
        <!-- EMAIL -->
        <!-- ========================= -->

        <div class="form-floating mt-3 mb-3">

            <input
                type="email"
                name="email_usuario"
                id="email_usuario"
                placeholder="Email"
                class="form-control"
                required
            >

            <label for="email_usuario">
                Email
            </label>

        </div>


        <!-- ========================= -->
        <!-- SENHA -->
        <!-- ========================= -->

        <div class="form-floating mt-3 mb-3">

            <input
                type="password"
                name="senha_usuario"
                id="senha_usuario"
                placeholder="Senha"
                class="form-control"
                minlength="3"
                maxlength="8"
                required
            >

            <label for="senha_usuario">
                Senha
            </label>

        </div>


        <!-- ========================= -->
        <!-- CONFIRMAR SENHA -->
        <!-- ========================= -->

        <div class="form-floating mt-3 mb-3">

            <input
                type="password"
                name="confirmarSenhaUsuario"
                id="confirmarSenhaUsuario"
                placeholder="Confirme a Senha"
                class="form-control"
                minlength="3"
                maxlength="8"
                required
            >

            <label for="confirmarSenhaUsuario">
                Confirme a Senha
            </label>

        </div>


        <!-- ========================= -->
        <!-- BOTÃO -->
        <!-- ========================= -->

        <button
            type="submit"
            class="btn btn-outline-dark"
        >
            Cadastrar
        </button>


    </form>

</div>


<!-- ========================= -->
<!-- JAVASCRIPT CPF / CNPJ -->
<!-- ========================= -->

<script>

const campoDocumento =
    document.getElementById("cpf_cnpj_usuario");

const dadosEmpresa =
    document.getElementById("dadosEmpresa");

const avisoCnpj =
    document.getElementById("avisoCnpj");

const dataNascimento =
    document.getElementById("dataNascimento_Usuario");

const nomeEmpresa =
    document.getElementById("nome_empresa");

const telefone =
    document.getElementById("telefone_usuario");

const endereco =
    document.getElementById("endereco_usuario");

const instagram =
    document.getElementById("instagram_usuario");


campoDocumento.addEventListener("input", function () {


    // Pega somente os números

    let numeros =
        this.value.replace(/\D/g, "");


    // Nunca deixa passar de 14 números

    numeros =
        numeros.substring(0, 14);


    // =================================
    // CPF
    // =================================

    if (numeros.length <= 11) {


        // Máscara CPF

        this.value =
            numeros
                .replace(/(\d{3})(\d)/, "$1.$2")
                .replace(/(\d{3})(\d)/, "$1.$2")
                .replace(/(\d{3})(\d{1,2})$/, "$1-$2");


        // Esconde empresa

        dadosEmpresa.style.display = "none";

        avisoCnpj.style.display = "none";


        // Empresa não é obrigatória

        nomeEmpresa.required = false;

        telefone.required = false;

        endereco.required = false;

        instagram.required = false;


        // Data de nascimento volta

        dataNascimento.parentElement.style.display = "block";

        dataNascimento.required = true;

    }


    // =================================
    // CNPJ
    // =================================

    else {


        // Máscara CNPJ

        this.value =
            numeros
                .replace(/^(\d{2})(\d)/, "$1.$2")
                .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
                .replace(/\.(\d{3})(\d)/, ".$1/$2")
                .replace(/(\d{4})(\d)/, "$1-$2");


        // Mostra empresa

        dadosEmpresa.style.display = "block";

        avisoCnpj.style.display = "block";


        // Campos obrigatórios

        nomeEmpresa.required = true;

        telefone.required = true;

        endereco.required = true;

        instagram.required = true;


        // CNPJ não precisa de data de nascimento

        dataNascimento.parentElement.style.display = "none";

        dataNascimento.required = false;

        dataNascimento.value = "";

    }

});

</script>


<?php include "footer.php" ?>