<?php

include "header.php";
include "conexaoBD.php";


// Verifica se recebeu o ID da loja
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {

    echo "<div class='container mt-5'>
            <div class='alert alert-danger text-center'>
                Loja não encontrada!
            </div>
          </div>";

    include "footer.php";
    exit();
}


// Pega o ID da loja
$idUsuario = intval($_GET['id']);

// =========================
// BUSCA OS DADOS DA LOJA
// =========================

$sqlLoja = "SELECT
                id_usuario,
                nome_empresa,
                cidade_usuario,
                instagram_usuario,
                site_usuario
            FROM usuario
            WHERE id_usuario = $idUsuario
            AND tipo_usuario = 'Microempreendedor'
            AND status_usuario = 'Ativo'";

$resultadoLoja = mysqli_query($conn, $sqlLoja);


// Verifica se a loja existe
if (mysqli_num_rows($resultadoLoja) == 0) {

    echo "<div class='container mt-5'>
            <div class='alert alert-danger text-center'>
                Loja não encontrada!
            </div>
          </div>";

    include "footer.php";
    exit();
}


$loja = mysqli_fetch_assoc($resultadoLoja);


// =========================
// BUSCA OS ANÚNCIOS DA LOJA
// =========================

$sqlAnuncios = "SELECT
                    idAnuncio,
                    Usuarios_idUsuario,
                    fotoAnuncio,
                    tituloAnuncio,
                    descricaoAnuncio,
                    categoriaAnuncio,
                    valorAnuncio,
                    dataAnuncio,
                    horaAnuncio,
                    statusAnuncio
                FROM Anuncios
                WHERE Usuarios_idUsuario = $idUsuario
                AND statusAnuncio = 'Disponível'
                ORDER BY dataAnuncio DESC, horaAnuncio DESC";

$resultadoAnuncios = mysqli_query($conn, $sqlAnuncios);

?>


<div class="container mt-5 mb-5">


    <!-- =========================
         INFORMAÇÕES DA LOJA
    ========================= -->

    <div class="text-center mb-5">

        <h1 class="fw-bold">
            🏪 <?= htmlspecialchars($loja['nome_empresa']) ?>
        </h1>


        <?php if (!empty($loja['cidade_usuario'])) { ?>

            <p class="text-muted">
                📍 <?= htmlspecialchars($loja['cidade_usuario']) ?>
            </p>

        <?php } ?>


        <?php if (!empty($loja['instagram_usuario'])) { ?>

            <p>
                📸 <?= htmlspecialchars($loja['instagram_usuario']) ?>
            </p>

        <?php } ?>


        <?php if (!empty($loja['site_usuario'])) { ?>

            <a 
                href="<?= htmlspecialchars($loja['site_usuario']) ?>"
                target="_blank"
                class="btn btn-primary"
            >
                🌐 Visitar site
            </a>

        <?php } ?>

    </div>



    <!-- =========================
         ANÚNCIOS DA LOJA
    ========================= -->

    <h2 class="mb-4">
        📋 Anúncios da loja
    </h2>


    <div class="row">


        <?php if (mysqli_num_rows($resultadoAnuncios) > 0) { ?>


            <?php while ($anuncio = mysqli_fetch_assoc($resultadoAnuncios)) { ?>


                <div class="col-md-4 mb-4">


                    <div class="card h-100 shadow-sm">


                        <!-- FOTO -->

                        <img 
                            src="<?= htmlspecialchars($anuncio['fotoAnuncio']) ?>"
                            class="card-img-top"
                            style="height: 220px; object-fit: cover;"
                            alt="<?= htmlspecialchars($anuncio['tituloAnuncio']) ?>"
                        >


                        <div class="card-body">


                            <!-- TÍTULO -->

                            <h5 class="card-title fw-bold">

                                <?= htmlspecialchars($anuncio['tituloAnuncio']) ?>

                            </h5>


                            <!-- CATEGORIA -->

                            <p class="text-muted">

                                <?= htmlspecialchars($anuncio['categoriaAnuncio']) ?>

                            </p>


                            <!-- DESCRIÇÃO -->

                            <p>

                                <?= htmlspecialchars($anuncio['descricaoAnuncio']) ?>

                            </p>


                            <!-- VALOR -->

                            <p class="fw-bold">

                                R$ 

                                <?= number_format(
                                    $anuncio['valorAnuncio'],
                                    2,
                                    ',',
                                    '.'
                                ) ?>

                            </p>


                            <!-- BOTÃO -->

                            <a 
                                href="post.php?id=<?= $anuncio['idAnuncio'] ?>"
                                class="btn btn-primary"
                            >
                                Ver anúncio
                            </a>


                        </div>

                    </div>

                </div>


            <?php } ?>


        <?php } else { ?>


            <div class="col-12">

                <div class="alert alert-info text-center">

                    Essa loja ainda não possui anúncios.

                </div>

            </div>


        <?php } ?>


    </div>

</div>


<?php include "footer.php"; ?>