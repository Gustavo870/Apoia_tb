<div class="col-lg-4">

    <div class="card mb-4">

        <div class="card-header">
            Buscar
        </div>

        <div class="card-body">

            <form action="pesquisa.php" method="GET">

                <div class="input-group">

                    <input
                        class="form-control"
                        type="text"
                        name="busca"
                        placeholder="O que você procura?"
                        aria-label="O que você procura?"
                    >

                    <button
                        class="btn btn-primary"
                        type="submit"
                    >
                        Pesquisar
                    </button>

                </div>

            </form>

        </div>

    </div>


    <div class="card mb-4">

        <div class="card-header">
            Categorias
        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-sm-6">

                    <ul class="list-unstyled mb-0">

                        <li>
                            <a href="#!">Alimentação</a>
                        </li>

                        <li>
                            <a href="#!">Artesanatos</a>
                        </li>

                        <li>
                            <a href="#!">Moda</a>
                        </li>

                    </ul>

                </div>


                <div class="col-sm-6">

                    <ul class="list-unstyled mb-0">

                        <li>
                            <a href="#!">Higiene</a>
                        </li>

                        <li>
                            <a href="#!">Produtos Naturais</a>
                        </li>

                        <li>
                            <a href="#!">Eletrônicos</a>
                        </li>

                    </ul>

                </div>

            </div>

        </div>

    </div>

</div>
