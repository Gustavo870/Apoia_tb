<?php include "header.php" ?>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome_usuario = $email_usuario = $senha_usuario = $cpf_cnpj_usuario = $status_usuario = $data_cadastro = $tipo_usuario = $telefone_usuario = $endereco_usuario = $cidade_usuario = $instagram_usuario = $fotoLoja ="";

    $data_cadastro = date("Y-m-d");
    $erroPreenchimento = false;

    if (empty($_POST["nome_usuario"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>NOME</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $nome_usuario = filtrar_entrada($_POST["nome_usuario"]);

        if (!preg_match('/^[\p{L} ]+$/u', $nome_usuario)) {

            echo "<div class='alert alert-warning text-center'>
                    O campo <strong>NOME</strong> deve conter apenas letras!
                  </div>";

            $erroPreenchimento = true;
        }
    }

    if (empty($_POST["email_usuario"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>EMAIL</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $email_usuario = filtrar_entrada($_POST["email_usuario"]);
    }

    if (empty($_POST["senha_usuario"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>SENHA</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $senha_usuario = md5(
            filtrar_entrada($_POST["senha_usuario"])
        );
    }

    if (empty($_POST["cpf_cnpj_usuario"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>CPF/CNPJ</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $cpf_cnpj_usuario = filtrar_entrada(
            $_POST["cpf_cnpj_usuario"]
        );

        $documento = preg_replace(
            '/\D/',
            '',
            $cpf_cnpj_usuario
        );

        if (strlen($documento) == 11) {

            $tipo_usuario = "Cliente";

            $cpf_cnpj_usuario = preg_replace(
                "/(\d{3})(\d{3})(\d{3})(\d{2})/",
                "$1.$2.$3-$4",
                $documento
            );

        } elseif (strlen($documento) == 14) {

            $tipo_usuario = "Microempreendedor";

            $cpf_cnpj_usuario = preg_replace(
                "/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/",
                "$1.$2.$3/$4-$5",
                $documento
            );

        } else {

            echo "<div class='alert alert-danger text-center'>
                    Digite um CPF com 11 números
                    ou um CNPJ com 14 números!
                  </div>";

            $erroPreenchimento = true;
        }
    }

    if (isset($_POST["telefone_usuario"])) {
        $telefone_usuario = filtrar_entrada(
            $_POST["telefone_usuario"]
        );
    }

    if (isset($_POST["endereco_usuario"])) {
        $endereco_usuario = filtrar_entrada(
            $_POST["endereco_usuario"]
        );
    }

    if (isset($_POST["cidade_usuario"])) {
        $cidade_usuario = filtrar_entrada(
            $_POST["cidade_usuario"]
        );
    }

    if (isset($_POST["instagram_usuario"])) {
        $instagram_usuario = filtrar_entrada(
            $_POST["instagram_usuario"]
        );
    }

    $status_usuario = "Ativo";

    if (!$erroPreenchimento) {

        include "conexaoBD.php";

        $nome_usuario = mysqli_real_escape_string($conn, $nome_usuario);
        $email_usuario = mysqli_real_escape_string($conn, $email_usuario);
        $senha_usuario = mysqli_real_escape_string($conn, $senha_usuario);
        $cpf_cnpj_usuario = mysqli_real_escape_string($conn, $cpf_cnpj_usuario);
        $status_usuario = mysqli_real_escape_string($conn, $status_usuario);
        $tipo_usuario = mysqli_real_escape_string($conn, $tipo_usuario);
        $telefone_usuario = mysqli_real_escape_string($conn, $telefone_usuario);
        $endereco_usuario = mysqli_real_escape_string($conn, $endereco_usuario);
        $cidade_usuario = mysqli_real_escape_string($conn, $cidade_usuario);
        $instagram_usuario = mysqli_real_escape_string($conn, $instagram_usuario);

        $inserirUsuario = "INSERT INTO usuario 
        (
            nome_usuario,
            email_usuario,
            senha_usuario,
            cpf_cnpj_usuario,
            status_usuario,
            data_cadastro,
            tipo_usuario,
            telefone_usuario,
            endereco_usuario,
            cidade_usuario,
            instagram_usuario,
            fotoLoja
        ) 
        VALUES 
        (
            '$nome_usuario',
            '$email_usuario',
            '$senha_usuario',
            '$cpf_cnpj_usuario',
            '$status_usuario',
            '$data_cadastro',
            '$tipo_usuario',
            '$telefone_usuario',
            '$endereco_usuario',
            '$cidade_usuario',
            '$instagram_usuario',
            '$fotoLoja'
        )";

        if (mysqli_query($conn, $inserirUsuario)) {

            echo "<div class='alert alert-success text-center'>
                    O cadastro do <strong>USUÁRIO</strong> foi efetuado com sucesso!
                  </div>";

            echo "
                <div class='container mb-3 mt-3'>

                    <table class='table table-bordered'>

                        <tr>
                            <th>NOME</th>
                            <td>$nome_usuario</td>
                        </tr>

                        <tr>
                            <th>EMAIL</th>
                            <td>$email_usuario</td>
                        </tr>

                        <tr>
                            <th>CPF/CNPJ</th>
                            <td>$cpf_cnpj_usuario</td>
                        </tr>

                        <tr>
                            <th>TIPO DE USUÁRIO</th>
                            <td>$tipo_usuario</td>
                        </tr>

                        <tr>
                            <th>STATUS</th>
                            <td>$status_usuario</td>
                        </tr>

                        <tr>
                            <th>DATA</th>
                            <td>$data_cadastro</td>
                        </tr>

                        <tr>
                            <th>TELEFONE</th>
                            <td>$telefone_usuario</td>
                        </tr>

                        <tr>
                            <th>ENDEREÇO</th>
                            <td>$endereco_usuario</td>
                        </tr>

                        <tr>
                            <th>CIDADE</th>
                            <td>$cidade_usuario</td>
                        </tr>

                        <tr>
                            <th>INSTAGRAM</th>
                            <td>$instagram_usuario</td>
                        </tr>

                    </table>

                </div>
            ";

        } else {

            echo "<div class='alert alert-danger text-center'>
                    Erro ao tentar cadastrar <strong>USUÁRIO</strong> no banco de dados!
                  </div>";

            echo "<div class='alert alert-danger text-center'>
                    Erro: " . mysqli_error($conn) . "
                  </div>";
        }
    }

} else {

    header("location:formUsuario.php");
    exit();
}

function filtrar_entrada($dado)
{
    $dado = trim($dado);
    $dado = stripslashes($dado);
    $dado = htmlspecialchars($dado);

    return $dado;
}

?>

<?php include "footer.php" ?>