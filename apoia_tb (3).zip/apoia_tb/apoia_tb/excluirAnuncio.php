<?php

session_start();

include "conexaoBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("location:login.php");
    exit();
}

$idUsuario = $_SESSION['id_usuario'];

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {

    $mensagem = "Anúncio inválido!";
    $descricao = "O anúncio informado não existe.";
    $tipo = "erro";

} else {

    $idAnuncio = intval($_GET['id']);

    $sql = "DELETE FROM Anuncios
            WHERE idAnuncio = $idAnuncio
            AND Usuarios_idUsuario = $idUsuario";

    if (mysqli_query($conn, $sql)) {

        if (mysqli_affected_rows($conn) > 0) {

            $mensagem = "Anúncio excluído!";
            $descricao = "O anúncio foi excluído com sucesso.";
            $tipo = "sucesso";

        } else {

            $mensagem = "Acesso negado!";
            $descricao = "Você não pode excluir um anúncio que pertence a outra conta.";
            $tipo = "erro";
        }

    } else {

        $mensagem = "Erro!";
        $descricao = "Não foi possível excluir o anúncio.";
        $tipo = "erro";
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Apoia TB</title>

    <link rel="stylesheet" href="style.css">

</head>

<body>

    <div class="aviso-exclusao">

        <?php if ($tipo == "sucesso") { ?>

            <div class="icone-exclusao sucesso">
                ✓
            </div>

        <?php } else { ?>

            <div class="icone-exclusao erro">
                !
            </div>

        <?php } ?>

        <h2 class="<?php echo $tipo; ?>">
            <?php echo $mensagem; ?>
        </h2>

        <p>
            <?php echo $descricao; ?>
        </p>

        <p class="voltando">
            Voltando para a página inicial...
        </p>

        <div class="barra-exclusao">

            <div class="progresso-exclusao <?php echo $tipo; ?>"></div>

        </div>

    </div>

    <script>

        setTimeout(function() {

            window.location.href = "index.php";

        }, 3000);

    </script>

</body>

</html>