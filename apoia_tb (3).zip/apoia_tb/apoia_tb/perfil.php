<?php

session_start();

include "header.php";
include "conexaoBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION['id_usuario'];

$sql = "SELECT 
            id_usuario,
            nome_usuario,
            email_usuario,
            cpf_cnpj_usuario,
            cidade_usuario,
            telefone_usuario,
            endereco_usuario,
            instagram_usuario,
            status_usuario,
            data_cadastro,
            fotoLoja
        FROM usuario
        WHERE id_usuario = $idUsuario";

$resultado = mysqli_query($conn, $sql);

if (!$resultado || mysqli_num_rows($resultado) == 0) {

    echo "<div class='container mt-5'>
            <div class='alert alert-danger text-center'>
                Usuário não encontrado!
            </div>
          </div>";

    include "footer.php";
    exit();
}

$usuario = mysqli_fetch_assoc($resultado);

?>

<div class="container mt-5 mb-5">

    <div class="perfil-card">

        <div class="text-center mb-4">

            <h1>Meu Perfil</h1>

            <p class="text-muted">
                Visualize e altere seus dados
            </p>

        </div>


        <form 
            action="editarPerfil.php" 
            method="POST" 
            enctype="multipart/form-data"
        >

            <!-- FOTO DA LOJA -->

            <div class="foto-loja-container">

                <label class="form-label fw-bold">
                    Foto da loja
                </label>

                <?php if (!empty($usuario['fotoLoja'])) { ?>

                    <img
                        src="<?= htmlspecialchars($usuario['fotoLoja']) ?>"
                        alt="Foto da loja"
                        class="foto-loja-preview"
                    >

                <?php } else { ?>

                    <div class="foto-loja-placeholder">
                        🏪
                    </div>

                <?php } ?>

                <input
                    type="file"
                    name="foto_loja"
                    class="form-control"
                    accept="image/jpeg,image/png,image/webp"
                >

                <small class="text-muted">
                    Escolha uma imagem para representar sua loja.
                </small>

            </div>


            <input 
                type="hidden" 
                name="id_usuario" 
                value="<?= $usuario['id_usuario'] ?>"
            >


            <!-- NOME -->

            <div class="mb-3">

                <label class="form-label">
                    Nome
                </label>

                <input
                    type="text"
                    name="nome_usuario"
                    class="form-control"
                    value="<?= htmlspecialchars($usuario['nome_usuario']) ?>"
                    required
                >

            </div>


            <!-- EMAIL -->

            <div class="mb-3">

                <label class="form-label">
                    E-mail
                </label>

                <input
                    type="email"
                    name="email_usuario"
                    class="form-control"
                    value="<?= htmlspecialchars($usuario['email_usuario']) ?>"
                    required
                >

            </div>


            <!-- CPF / CNPJ -->

            <div class="mb-3">

                <label class="form-label">
                    CPF/CNPJ
                </label>

                <input
                    type="text"
                    class="form-control"
                    value="<?= htmlspecialchars($usuario['cpf_cnpj_usuario']) ?>"
                    readonly
                >

            </div>


            <!-- CIDADE -->

            <div class="mb-3">

                <label class="form-label">
                    Cidade
                </label>

                <select
                    name="cidade_usuario"
                    class="form-control"
                >

                    <option value="Curiúva" <?= $usuario['cidade_usuario'] == 'Curiúva' ? 'selected' : '' ?>>
                        Curiúva
                    </option>

                    <option value="Imbaú" <?= $usuario['cidade_usuario'] == 'Imbaú' ? 'selected' : '' ?>>
                        Imbaú
                    </option>

                    <option value="Ortigueira" <?= $usuario['cidade_usuario'] == 'Ortigueira' ? 'selected' : '' ?>>
                        Ortigueira
                    </option>

                    <option value="Reserva" <?= $usuario['cidade_usuario'] == 'Reserva' ? 'selected' : '' ?>>
                        Reserva
                    </option>

                    <option value="Telêmaco Borba" <?= $usuario['cidade_usuario'] == 'Telêmaco Borba' ? 'selected' : '' ?>>
                        Telêmaco Borba
                    </option>

                    <option value="Tibagi" <?= $usuario['cidade_usuario'] == 'Tibagi' ? 'selected' : '' ?>>
                        Tibagi
                    </option>

                </select>

            </div>


            <!-- TELEFONE -->

            <div class="mb-3">

                <label class="form-label">
                    Telefone
                </label>

                <input
                    type="text"
                    name="telefone_usuario"
                    class="form-control"
                    value="<?= htmlspecialchars($usuario['telefone_usuario']) ?>"
                >

            </div>


            <!-- ENDEREÇO -->

            <div class="mb-3">

                <label class="form-label">
                    Endereço
                </label>

                <input
                    type="text"
                    name="endereco_usuario"
                    class="form-control"
                    value="<?= htmlspecialchars($usuario['endereco_usuario']) ?>"
                >

            </div>


            <!-- INSTAGRAM -->

            <div class="mb-3">

                <label class="form-label">
                    Instagram
                </label>

                <input
                    type="text"
                    name="instagram_usuario"
                    class="form-control"
                    value="<?= htmlspecialchars($usuario['instagram_usuario']) ?>"
                    placeholder="https://instagram.com/seuusuario"
                >

            </div>


            <!-- STATUS -->

            <div class="mb-3">

                <label class="form-label">
                    Status
                </label>

                <input
                    type="text"
                    class="form-control"
                    value="<?= htmlspecialchars($usuario['status_usuario']) ?>"
                    readonly
                >

            </div>


            <!-- DATA -->

            <div class="mb-4">

                <label class="form-label">
                    Data de cadastro
                </label>

                <input
                    type="text"
                    class="form-control"
                    value="<?= date('d/m/Y', strtotime($usuario['data_cadastro'])) ?>"
                    readonly
                >

            </div>


            <!-- BOTÕES -->

            <div class="d-flex justify-content-between">

                <a
                    href="index.php"
                    class="btn btn-secondary"
                >
                    Voltar
                </a>

                <button
                    type="submit"
                    class="btn btn-dark"
                >
                    Salvar alterações
                </button>

            </div>

        </form>

    </div>

</div>

<?php include "footer.php"; ?>