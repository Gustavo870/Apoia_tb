<?php 
 
session_start(); 
 
include "header.php"; 
include "conexaoBD.php"; 
 
$busca = $_GET['busca'] ?? ''; 
$busca = trim($busca); 
 
?> 
 
<div class="container mt-5"> 
 
    <div class="row"> 
 
        <div class="col-lg-8"> 
 
            <h1 class="mb-4"> 
                Resultados da pesquisa 
            </h1> 
 
            <?php 
 
            if ($busca == '') { 
 
            ?> 
 
                <div class="alert alert-warning"> 
                    Digite algo no campo de pesquisa. 
                </div> 
 
            <?php 
 
            } else { 
 
                $buscaBanco = mysqli_real_escape_string( 
                    $conn, 
                    $busca 
                ); 
 
                $sql = "SELECT 
                            Anuncios.idAnuncio, 
                            Anuncios.fotoAnuncio, 
                            Anuncios.tituloAnuncio, 
                            Anuncios.descricaoAnuncio, 
                            Anuncios.categoriaAnuncio, 
                            Anuncios.valorAnuncio, 
                            Anuncios.dataAnuncio, 
                            usuario.nome_usuario 
                        FROM Anuncios 
                        INNER JOIN usuario 
                            ON Anuncios.Usuarios_idUsuario = usuario.id_usuario 
                        WHERE Anuncios.tituloAnuncio LIKE '%$buscaBanco%' 
                        ORDER BY Anuncios.dataAnuncio DESC"; 
 
                $resultado = mysqli_query($conn, $sql); 
 
                if (!$resultado) { 
 
                ?> 
 
                    <div class="alert alert-danger"> 
                        Erro ao realizar a pesquisa. 
                    </div> 
 
                <?php 
 
                } elseif (mysqli_num_rows($resultado) == 0) { 
 
                ?> 
 
                    <div class="alert alert-danger"> 
 
                        Nenhum anúncio encontrado para: 
 
                        <strong> 
                            <?= htmlspecialchars($busca) ?> 
                        </strong> 
 
                    </div> 
 
                <?php 
 
                } else { 
 
                ?> 
 
                    <p class="text-muted mb-4"> 
 
                        Resultados para: 
 
                        <strong> 
                            <?= htmlspecialchars($busca) ?> 
                        </strong> 
 
                    </p> 
 
                    <div class="row"> 
 
                        <?php 
 
                        while ($anuncio = mysqli_fetch_assoc($resultado)) { 
 
                        ?> 
 
                            <div class="col-md-6 mb-4"> 
 
                                <div class="card h-100"> 
 
                                    <img 
                                        src="<?= htmlspecialchars($anuncio['fotoAnuncio']) ?>" 
                                        class="card-img-top" 
                                        alt="<?= htmlspecialchars($anuncio['tituloAnuncio']) ?>" 
                                        style=" 
                                            height: 260px; 
                                            width: 100%; 
                                            object-fit: contain; 
                                        " 
                                    > 
 
                                    <div class="card-body d-flex flex-column"> 
 
                                        <h2 class="card-title"> 
                                            <?= htmlspecialchars($anuncio['tituloAnuncio']) ?> 
                                        </h2> 
 
                                        <p class="card-text"> 
 
                                            <?= htmlspecialchars( 
                                                mb_substr( 
                                                    $anuncio['descricaoAnuncio'], 
                                                    0, 
                                                    100 
                                                ) 
                                            ) ?> 
 
                                            <?php 
 
                                            if ( 
                                                mb_strlen( 
                                                    $anuncio['descricaoAnuncio'] 
                                                ) > 100 
                                            ) { 
 
                                                echo "..."; 
 
                                            } 
 
                                            ?> 
 
                                        </p> 
 
                                        <p class="card-text"> 
 
                                            <strong> 
 
                                                R$ 
 
                                                <?= number_format( 
                                                    $anuncio['valorAnuncio'], 
                                                    2, 
                                                    ',', 
                                                    '.' 
                                                ) ?> 
 
                                            </strong> 
 
                                        </p> 
 
                                        <a 
                                            href="anuncio.php?id=<?= $anuncio['idAnuncio'] ?>" 
                                            class="btn btn-primary mt-auto" 
                                        > 
                                            Ler mais 
                                        </a> 
 
                                    </div> 
 
                                </div> 
 
                            </div> 
 
                        <?php 
 
                        } 
 
                        ?> 
 
                    </div> 
 
                <?php 
 
                } 
 
            } 
 
            ?> 
 
        </div> 
 
        <?php include "Widgtes.php"; ?> 
 
    </div> 
 
</div> 
 
<?php include "footer.php"; ?>