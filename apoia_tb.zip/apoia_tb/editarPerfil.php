<?php

session_start();

include "conexaoBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION['id_usuario'];

$nome_usuario = trim($_POST['nome_usuario']);
$email_usuario = trim($_POST['email_usuario']);
$cidade_usuario = trim($_POST['cidade_usuario']);
$telefone_usuario = trim($_POST['telefone_usuario']);
$endereco_usuario = trim($_POST['endereco_usuario']);
$instagram_usuario = trim($_POST['instagram_usuario']);

if (
    empty($nome_usuario) ||
    empty($email_usuario) ||
    empty($cidade_usuario)
) {

    header("Location: perfil.php?erro=1");
    exit();
}

$nome_usuario = mysqli_real_escape_string($conn, $nome_usuario);
$email_usuario = mysqli_real_escape_string($conn, $email_usuario);
$cidade_usuario = mysqli_real_escape_string($conn, $cidade_usuario);
$telefone_usuario = mysqli_real_escape_string($conn, $telefone_usuario);
$endereco_usuario = mysqli_real_escape_string($conn, $endereco_usuario);
$instagram_usuario = mysqli_real_escape_string($conn, $instagram_usuario);

$sql = "UPDATE usuario SET

        nome_usuario = '$nome_usuario',
        email_usuario = '$email_usuario',
        cidade_usuario = '$cidade_usuario',
        telefone_usuario = '$telefone_usuario',
        endereco_usuario = '$endereco_usuario',
        instagram_usuario = '$instagram_usuario'

        WHERE id_usuario = $idUsuario";

if (mysqli_query($conn, $sql)) {

    $_SESSION['nome_usuario'] = $nome_usuario;

    header("Location: perfil.php?sucesso=1");
    exit();

} else {

    echo "Erro ao atualizar perfil: " . mysqli_error($conn);

}

?>