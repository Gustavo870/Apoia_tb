<?php include "header.php" ?>



<!--php -->

    <div class="d-flex justify-content-center mb-3">
        <h2>Cadastre-se</h2>
    </div>

    <div class="d-flex justify-content-center mb-4">
        <form action="actionUsuario.php" method="POST" class="was-validated w-25"  enctype="multipart/form-data">


            <div class="form-floating mt-3 mb-3">
                <input type="text" name="nome_usuario" id="nome_usuario" placeholder="Nome Completo" class="form-control">
                <label for="nome_usuario">Nome</label>
                <div class="valid-feedback"></div>
                <div class="invalid-feedback"></div>
            </div>

            <div class="form-floating mt-3 mb-3" id="divCpf">
                <input 
                    type="text" 
                    name="cpf_cnpj_usuario" 
                    id="cpf_cnpj_usuario" 
                    class="form-control" 
                    placeholder="CPF ou CNPJ"
                    maxlength ="14"
                >
                <label for="cpf_cnpj_usuario">CPF ou CNPJ</label>
            </div>


            <div class="form-floating mt-3 mb-3">
                <input type="date" name="dataNascimento_Usuario" id="dataNascimento_Usuario" placeholder="Data de Nascimento" class="form-control">
                <label for="dataNascimentoUsuario">Data de Nascimento</label>
                <div class="valid-feedback"></div>
                <div class="invalid-feedback"></div>
            </div>

            <div class="form-floating mt-3 mb-3">
                <select name="cidadeUsuario" id="cidadeUsuario" placeholder="Cidade" class="form-control">
                    <option value="Curiúva">Curiúva</option>
                    <option value="Imbaú">Imbaú</option>
                    <option value="Ortigueira">Ortigueira</option>
                    <option value="Reserva">Reserva</option>
                    <option value="Telêmaco Borba" selected>Telêmaco Borba</option>
                    <option value="Tibagi">Tibagi</option>
                </select>
                <label for="cidadeUsuario">Cidade</label>
                <div class="valid-feedback"></div>
                <div class="invalid-feedback"></div>
            </div>

            <div class="form-floating mt-3 mb-3">
                <input type="email" name="email_usuario" id="email_usuario" placeholder="Email" class="form-control">
                <label for="email_usuario">Email</label>
                <div class="valid-feedback"></div>
                <div class="invalid-feedback"></div>
            </div>

            <div class="form-floating mt-3 mb-3">
                <input type="password" name="senha_usuario" id="senha_usuario" placeholder="Senha" class="form-control" minlength="3" maxlength="8">
                <label for="senha_usuario">Senha</label>
                <div class="valid-feedback"></div>
                <div class="invalid-feedback"></div>
            </div>

            <div class="form-floating mt-3 mb-3">
                <input type="password" name="confirmarSenhaUsuario" id="confirmarSenhaUsuario" placeholder="Confirme a Senha" class="form-control" minlength="3" maxlength="8">
                <label for="confirmarSenhaUsuario">Confirme a Senha</label>
                <div class="valid-feedback"></div>
                <div class="invalid-feedback"></div>
            </div>



            <button type="submit" class="btn btn-outline-dark">Cadastrar</button>

        </form>

    </div>
    

    <!-- java script -->

        <!-- Script para Máscaras de CPF e CNPJ -->
<?php include "footer.php" ?>