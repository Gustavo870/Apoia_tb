<?php

session_start();

if (!isset($_SESSION['id_usuario'])) {
    $idUsuario = 0;
} else {
    $idUsuario = $_SESSION['id_usuario'];
}

include "header.php";
include "conexaoBD.php";
$idUsuario = $_SESSION['id_usuario'] ?? 0;
// Verifica se recebeu o ID do anúncio
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<div class='container mt-5'>
            <div class='alert alert-danger text-center'>
                Anúncio não encontrado!
            </div>
          </div>";

    include "footer.php";
    exit();
}

// Pega o ID enviado pela URL
$idAnuncio = intval($_GET['id']);

// Busca o anúncio no banco
$sql = "SELECT 
            Anuncios.idAnuncio,
            Anuncios.Usuarios_idUsuario,
            Anuncios.fotoAnuncio,
            Anuncios.tituloAnuncio,
            Anuncios.descricaoAnuncio,
            Anuncios.categoriaAnuncio,
            Anuncios.valorAnuncio,
            Anuncios.dataAnuncio,
            Anuncios.horaAnuncio,
            Anuncios.statusAnuncio,
            usuario.nome_usuario,
            usuario.email_usuario,
            usuario.cidade_usuario,
            usuario.instagram_usuario
        FROM Anuncios
        INNER JOIN usuario 
            ON Anuncios.Usuarios_idUsuario = usuario.id_usuario
        WHERE Anuncios.idAnuncio = $idAnuncio";

$resultado = mysqli_query($conn, $sql);

// Verifica se encontrou o anúncio
if (mysqli_num_rows($resultado) == 0) {

    echo "<div class='container mt-5'>
            <div class='alert alert-danger text-center'>
                Anúncio não encontrado!
            </div>
          </div>";

    include "footer.php";
    exit();
}

// Pega os dados do anúncio
$anuncio = mysqli_fetch_assoc($resultado);

?>

<!-- Page content -->
<div class="container mt-5">

    <div class="row">

        <div class="col-lg-8">

            <!-- Post content -->
            <article>

                <!-- Post header -->
                <header class="mb-4">

                    <!-- Título -->
                    <h1 class="fw-bolder mb-1">
                        <?= htmlspecialchars($anuncio['tituloAnuncio']) ?>
                    </h1>

                    <!-- Data e hora -->
                    <div class="text-muted fst-italic mb-2">

                        Publicado em
                        <?= date("d/m/Y", strtotime($anuncio['dataAnuncio'])) ?>

                        às

                        <?= $anuncio['horaAnuncio'] ?>

                    </div>

                    <!-- Categoria -->
                    <span class="badge bg-secondary text-decoration-none link-light">
                        <?= htmlspecialchars($anuncio['categoriaAnuncio']) ?>
                    </span>

                </header>


                <!-- Foto do anúncio -->
                <figure class="mb-4 text-center">

                    <img
                        class="img-fluid rounded"
                        src="<?= htmlspecialchars($anuncio['fotoAnuncio']) ?>"
                        alt="<?= htmlspecialchars($anuncio['tituloAnuncio']) ?>"
                    >

                </figure>


                <!-- Conteúdo do anúncio -->
                <section class="mb-5">

                    <h2 class="fw-bolder mb-4">
                        <?= htmlspecialchars($anuncio['tituloAnuncio']) ?>
                    </h2>

                    <p class="fs-5 mb-4">

                        <?= nl2br(htmlspecialchars($anuncio['descricaoAnuncio'])) ?>

                    </p>


                    <!-- Informações do anúncio -->
                    <div class="card mb-4">

                        <div class="card-body">

                            <h4 class="fw-bolder mb-3">
                                Informações do anúncio
                            </h4>

                            <p>
                                <strong>Categoria:</strong>
                                <?= htmlspecialchars($anuncio['categoriaAnuncio']) ?>
                            </p>

                            <p>
                                <strong>Valor:</strong>

                                R$

                                <?= number_format(
                                    $anuncio['valorAnuncio'],
                                    2,
                                    ',',
                                    '.'
                                ) ?>

                            </p>

                            <p>
                                <strong>Status:</strong>

                                <?= htmlspecialchars($anuncio['statusAnuncio']) ?>

                            </p>

                        </div>

                    </div>
                    <!-- Informações da empresa -->
                    <div class="card mb-4">

                        <div class="card-body">

                            <h4 class="fw-bolder mb-3">
                                🏢 Sobre a empresa
                            </h4>

                            <p>
                                <strong>Nome:</strong>
                                <?= htmlspecialchars($anuncio['nome_usuario']) ?>
                            </p>

                            <p>
                                <strong>E-mail:</strong>
                                <?= htmlspecialchars($anuncio['email_usuario']) ?>
                            </p>

                            <p>
                                <strong>Cidade:</strong>
                                <?= htmlspecialchars($anuncio['cidade_usuario']) ?>
                            </p>

                            <?php if (!empty($anuncio['instagram_usuario'])) { ?>

                                <p>
                                    <strong>Instagram:</strong>
                                    <?= htmlspecialchars($anuncio['instagram_usuario']) ?>
                                </p>

                            <?php } ?>

                        </div>

                    </div>

                </section>

            </article>

            <?php if ($anuncio['Usuarios_idUsuario'] == $idUsuario) { ?>

                <div class="mb-4">
                    <a 
                        href="excluirAnuncio.php?id=<?= $anuncio['idAnuncio'] ?>"
                        class="btn btn-danger"
                        onclick="return confirm('Tem certeza que deseja excluir este anúncio?');"
                    >
                        Excluir anúncio
                    </a>
                </div>

            <?php } ?>


            <!-- Comments section -->
            <section class="mb-5">

                <div class="card bg-light">

                    <div class="card-body">

                        <!-- Comment form -->
                        <form class="mb-4">

                            <textarea
                                class="form-control"
                                rows="3"
                                placeholder="Deixe um comentário!"
                            ></textarea>

                        </form>


                        <!-- Comentário -->
                        <div class="d-flex mb-4">

                            <div class="flex-shrink-0">

                                <img
                                    class="rounded-circle"
                                    src="https://dummyimage.com/50x50/ced4da/6c757d.jpg"
                                    alt="Usuário"
                                >

                            </div>

                            <div class="ms-3">

                                <div class="fw-bold">
                                    Usuário
                                </div>

                                Este é um espaço para comentários.

                            </div>

                        </div>

                    </div>

                </div>

            </section>

        </div>



        <!-- Widget -->
        <?php include "Widgtes.php" ?>

    </div>

</div>


<?php include "footer.php" ?>