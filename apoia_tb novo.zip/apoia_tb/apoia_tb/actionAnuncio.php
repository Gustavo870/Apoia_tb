<?php include "header.php" ?>

<?php
// Verifica se o método de envio das informações do form é "POST"
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Cria variáveis para armazenar as informações recebidas do array $_POST
    $fotoAnuncio = $tituloAnuncio = $descricaoAnuncio = $categoriaAnuncio = $valorAnuncio = "";

    // Variável booleana para controle de erros de preenchimento
    $erroPreenchimento = false;

    // Variáveis para armazenar a data e a hora do anúncio
    $dataAnuncio = date("Y-m-d");
    $horaAnuncio = date("H:i:s");

    // =========================
    // VALIDAÇÃO DO TÍTULO
    // =========================

    if (empty($_POST["tituloAnuncio"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>TÍTULO DO ANÚNCIO</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $tituloAnuncio = filtrar_entrada($_POST["tituloAnuncio"]);
    }


    // =========================
    // VALIDAÇÃO DA DESCRIÇÃO
    // =========================

    if (empty($_POST["descricaoAnuncio"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>DESCRIÇÃO DO ANÚNCIO</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $descricaoAnuncio = filtrar_entrada($_POST["descricaoAnuncio"]);
    }


    // =========================
    // VALIDAÇÃO DA CATEGORIA
    // =========================

    if (empty($_POST["categoriaAnuncio"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>CATEGORIA</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $categoriaAnuncio = filtrar_entrada($_POST["categoriaAnuncio"]);
    }


    // =========================
    // VALIDAÇÃO DO VALOR
    // =========================

    if (empty($_POST["valorAnuncio"])) {

        echo "<div class='alert alert-warning text-center'>
                O campo <strong>VALOR DO ANÚNCIO</strong> é obrigatório!
              </div>";

        $erroPreenchimento = true;

    } else {

        $valorAnuncio = filtrar_entrada($_POST["valorAnuncio"]);
    }


    // =========================
    // VALIDAÇÃO DA FOTO
    // =========================

    $diretorio = "assets/img/";
    $erroUpload = false;

    // Verifica se o arquivo foi enviado
    if (isset($_FILES["fotoAnuncio"]) && $_FILES["fotoAnuncio"]["error"] == 0) {

        // Monta o caminho da imagem
        $nomeArquivo = basename($_FILES["fotoAnuncio"]["name"]);
        $fotoAnuncio = $diretorio . $nomeArquivo;

        // Pega a extensão da imagem
        $tipoDaImagem = strtolower(pathinfo($fotoAnuncio, PATHINFO_EXTENSION));


        // Verifica o tamanho da foto
        if ($_FILES["fotoAnuncio"]["size"] > 5000000) {

            echo "<div class='alert alert-warning text-center'>
                    A <strong>FOTO</strong> deve ser menor do que 5MB!
                  </div>";

            $erroUpload = true;
        }


        // Verifica o formato da foto
        if (
            $tipoDaImagem != "jpg" &&
            $tipoDaImagem != "jpeg" &&
            $tipoDaImagem != "png" &&
            $tipoDaImagem != "webp"
        ) {

            echo "<div class='alert alert-warning text-center'>
                    A <strong>FOTO</strong> deve estar nos formatos JPG, JPEG, PNG ou WEBP!
                  </div>";

            $erroUpload = true;
        }


        // Só tenta mover a foto se não houver erro
        if (!$erroUpload) {

            if (!move_uploaded_file(
                $_FILES["fotoAnuncio"]["tmp_name"],
                $fotoAnuncio
            )) {

                echo "<div class='alert alert-danger text-center'>
                        Erro ao tentar mover a foto para o diretório
                        <strong>$diretorio</strong>!
                      </div>";

                $erroUpload = true;
            }
        }

    } else {

        echo "<div class='alert alert-warning text-center'>
                A <strong>FOTO</strong> é obrigatória!
              </div>";

        $erroUpload = true;
    }


    // =========================
    // CADASTRO NO BANCO
    // =========================

    if (!$erroPreenchimento && !$erroUpload) {

        // Inclui o arquivo de conexão com o Banco de Dados
        include "conexaoBD.php";


        // Cria a QUERY para inserir o anúncio
        $inserirAnuncio = "INSERT INTO Anuncios
        (
            Usuarios_idUsuario,
            fotoAnuncio,
            tituloAnuncio,
            descricaoAnuncio,
            categoriaAnuncio,
            valorAnuncio,
            dataAnuncio,
            horaAnuncio,
            statusAnuncio
        )
        VALUES
        (
            $idUsuario,
            '$fotoAnuncio',
            '$tituloAnuncio',
            '$descricaoAnuncio',
            '$categoriaAnuncio',
            '$valorAnuncio',
            '$dataAnuncio',
            '$horaAnuncio',
            'Disponível'
        )";


        // Executa a QUERY no Banco de Dados
        if (mysqli_query($conn, $inserirAnuncio)) {

            // Mensagem de sucesso
            echo "<div class='alert alert-success text-center'>
                    O cadastro do <strong>ANÚNCIO</strong> foi efetuado com sucesso!
                  </div>";


            // Exibe os dados cadastrados
            echo "
                <div class='container mb-3 mt-3'>

                    <div class='container mb-3 mt-3 text-center'>

                        <img
                            src='$fotoAnuncio'
                            title='Foto de $tituloAnuncio'
                            style='width:150px'
                            class='img-thumbnail'
                        >

                    </div>


                    <table class='table table-bordered'>

                        <tr>
                            <th>TÍTULO DO ANÚNCIO</th>
                            <td>$tituloAnuncio</td>
                        </tr>

                        <tr>
                            <th>DESCRIÇÃO DO ANÚNCIO</th>
                            <td>$descricaoAnuncio</td>
                        </tr>

                        <tr>
                            <th>CATEGORIA</th>
                            <td>$categoriaAnuncio</td>
                        </tr>

                        <tr>
                            <th>VALOR DO ANÚNCIO</th>
                            <td>$valorAnuncio</td>
                        </tr>

                        <tr>
                            <th>DATA DO ANÚNCIO</th>
                            <td>$dataAnuncio</td>
                        </tr>

                        <tr>
                            <th>HORA DO ANÚNCIO</th>
                            <td>$horaAnuncio</td>
                        </tr>

                        <tr>
                            <th>USUÁRIO ANUNCIANTE</th>
                            <td>$idUsuario</td>
                        </tr>

                    </table>

                </div>
            ";

        } else {

            // Caso ocorra erro no cadastro
            echo "<div class='alert alert-danger text-center'>
                    Erro ao tentar cadastrar o <strong>ANÚNCIO</strong>
                    no banco de dados!
                  </div>";

            // Mostra o erro do MySQL para facilitar a identificação do problema
            echo "<div class='alert alert-danger text-center'>
                    Erro: " . mysqli_error($conn) . "
                  </div>";
        }
    }

} else {

    // Se a página for acessada sem POST,
    // redireciona para o formulário
    header("location:formAnuncio.php");
    exit();
}


// =========================
// FUNÇÃO PARA FILTRAR DADOS
// =========================

function filtrar_entrada($dado)
{
    // Remove espaços desnecessários
    $dado = trim($dado);

    // Remove barras invertidas
    $dado = stripslashes($dado);

    // Converte caracteres especiais em entidades HTML
    $dado = htmlspecialchars($dado);

    // Retorna o dado filtrado
    return $dado;
}
?>

<?php include "footer.php" ?>